/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package GUIFinal.ListController;

/**
 *
 * @author aaratame
 */
public interface IListController {
    
    public void adicionar();
    
    public void editar(Object escolhido);
    
    public void remover();
    
    public void refresh();
    
}
