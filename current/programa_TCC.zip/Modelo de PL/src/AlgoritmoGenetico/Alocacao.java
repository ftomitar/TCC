package AlgoritmoGenetico;

/**
 *
 * @author felipe
 */
public enum Alocacao {

    BLOQUEADO(), DISPONIVEL(), INDISPONIVEL();

    private Alocacao() {
    }

}
